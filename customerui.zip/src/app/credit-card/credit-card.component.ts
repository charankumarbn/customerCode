import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NotificationService } from '../services/notification.service';

@Component({
  selector: 'app-credit-card',
  templateUrl: './credit-card.component.html',
  styleUrls: ['./credit-card.component.css']
})
export class CreditCardComponent implements OnInit {
requestCreditForm:FormGroup;
  constructor(private http:HttpClient,private notification:NotificationService) { }

  ngOnInit(): void {
    this.requestCreditForm = new FormGroup({
      'username' : new FormControl(null,Validators.required),
      'phonenumber':new FormControl(null,Validators.required),
      'address':new FormControl(null,Validators.required)
    })
  }

  onSubmit(){
    console.log(this.requestCreditForm);
    if(this.requestCreditForm.status == "VALID"){
      this.applyCreditCard(this.requestCreditForm.value);
    }
  }

  applyCreditCard(value){
    let params = {
        "customer": {
        "name":value.username,
        "address":value.address,
        "phonenumber":value.phonenumber
    },
    "phoneNumber":value.phonenumber
    }

    this.http.post("http://localhost:8081/customer/application/apply",params).subscribe((res :any) => {
      console.log(res);
      if(res.status){
        this.requestCreditForm.reset("");
     //   this.notification.showSuccess("Succesfully applied for credit card");
      }
    })
  }
}
