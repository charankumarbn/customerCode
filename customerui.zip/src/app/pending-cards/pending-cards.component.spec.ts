import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingCardsComponent } from './pending-cards.component';

describe('PendingCardsComponent', () => {
  let component: PendingCardsComponent;
  let fixture: ComponentFixture<PendingCardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PendingCardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
