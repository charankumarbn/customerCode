import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Component({
  selector: 'app-pending-cards',
  templateUrl: './pending-cards.component.html',
  styleUrls: ['./pending-cards.component.css']
})
export class PendingCardsComponent implements OnInit {

  pendingCards: any = [];
  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.getPendingCards()
  }


  getPendingCards() {
    this.pendingCards = [];
    this.http.get("http://192.168.1.3:8081/customer/application/pendingCards").subscribe((res: any) => {
      console.log(res);
      if (res.status) {
        this.pendingCards = res.data;
      }
    })
  }

  updatestatus(data, status) {
    console.log("update data", data);
    let param = {
      "id": data.id,
      "customer": {
        "id": data.customer.id,
        "name": data.customer.name,
        "address": data.customer.address,
        "phonenumber": data.customer.phonenumber
      },
      "phoneNumber": data.phoneNumber,
      "status": status
    }

    this.http.put("http://localhost:8081/customer/application/updateStatus", param).subscribe((res: any) => {
      console.log(res);
      if (res.status) {
        this.getPendingCards();
      }
    })
  }
}
