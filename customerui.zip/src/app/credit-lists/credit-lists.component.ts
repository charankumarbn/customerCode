import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credit-lists',
  templateUrl: './credit-lists.component.html',
  styleUrls: ['./credit-lists.component.css']
})
export class CreditListsComponent implements OnInit {

  allCards:any = [];
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.getPendingCards()
  }

 
  
  getPendingCards(){ 
    this.allCards = [];
    this.http.get("http://192.168.1.3:8081/customer/application/getAllCards").subscribe((res : any) =>{
      console.log(res);
      if(res.status){
        this.allCards = res.data;
      }
    })
  }

getStatuColor(status){
  let color = "";
  console.log("status color",status)
  switch(status){
    case "Pending":color="#d39e00";break;
    case "Approved":color="#1e7e34";break;
    case "Rejected":color="red";break;
  }
  return color;
}

}

