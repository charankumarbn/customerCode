import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreditListsComponent } from './credit-lists.component';

describe('CreditListsComponent', () => {
  let component: CreditListsComponent;
  let fixture: ComponentFixture<CreditListsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreditListsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditListsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
