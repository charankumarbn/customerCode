import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreditCardComponent } from './credit-card/credit-card.component';
import { PendingCardsComponent } from './pending-cards/pending-cards.component';
import { CreditListsComponent } from './credit-lists/credit-lists.component';


const routes: Routes = [

  {path:'credit-card',component:CreditCardComponent},
  {path:'pending-cards',component:PendingCardsComponent},
  {path:'credit-lists',component:CreditListsComponent},
  {path:'credit-card',redirectTo:"credit-card"}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
