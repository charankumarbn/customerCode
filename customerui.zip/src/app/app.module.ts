import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CreditCardComponent } from './credit-card/credit-card.component';
import { PendingCardsComponent } from './pending-cards/pending-cards.component';
import { CreditListsComponent } from './credit-lists/credit-lists.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
//import { ToastrModule, ToastrService } from 'ngx-toastr';
import { NotificationService } from './services/notification.service';
//import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


@NgModule({
  declarations: [
    AppComponent,
    CreditCardComponent,
    PendingCardsComponent,
    CreditListsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    HttpClientModule,
    // BrowserAnimationsModule
  ],
  providers: [HttpClient,NotificationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
